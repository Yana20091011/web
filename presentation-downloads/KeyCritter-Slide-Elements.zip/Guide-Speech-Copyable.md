# KeyCritter — copyable slide elements

## Slide 1: Title

Guide says:

```text
Hi! Welcome to KeyCritter!
```

## Slide 2: Problem

Guide says:

```text
Typing could use a little company…
```

## Slide 3: Creative process

Guide says:

```text
From an idea to a working companion.
```

## Slide 4: Demo

Guide says:

```text
Let me show you around!
```

## Slide 5: Tools

Guide says:

```text
These tools brought me to life.
```

## Slide 6: Comparison

Guide says:

```text
Let’s compare our features.
```

## Slide 7: Challenges

Guide says:

```text
This part took some debugging…
```

## Slide 8: How it works

Guide says:

```text
Every keystroke starts a reaction.
```

## Slide 9: My contribution

Guide says:

```text
Here’s the work behind the project.
```

## Slide 10: Results

Guide says:

```text
Look what we built!
```

## Slide 11: Takeaways

Guide says:

```text
What did we learn?
```

## Slide 12: Next steps

Guide says:

```text
There’s more to explore!
```

## Slide 13: Thank you

Guide says:

```text
Thanks for meeting me!
```

